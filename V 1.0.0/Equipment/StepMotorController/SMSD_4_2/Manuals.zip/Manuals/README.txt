You need to install 
CP210xVCP
Before starting